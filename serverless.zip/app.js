'use strict';

// const app = require('./server/app');

let AppBBVA = require(__dirname + '/server/components/App');
let config = AppBBVA.Config();
// process.env.NODE_ENV = config.env;
// let app = AppBBVA.launch();


// var express = require('express')
// var app = express()
//
// app.get('/', function (req, res) {
//     res.send('Hello World!')
// })

// app.listen(3000, function () {
//   console.log('Example app listening on port 3000!')
// })

module.exports = AppBBVA.launch();